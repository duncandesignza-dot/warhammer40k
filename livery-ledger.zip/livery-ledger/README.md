# Livery Ledger

Plan how you'll paint a Warhammer 40,000 army. Pick a faction, choose its colours, then track every unit with a photo, weapons, rank colours and paint recipes.

## Files

```
index.html               page shell
css/styles.css           all styles
js/config.js             your Supabase settings (edit this)
js/data/factions.js      factions, datasheets and weapons (generated)
js/data/presets.js       starting colours per faction, emblem shapes, colour names
js/art.js                helmet, roundel and pauldron artwork
js/store.js              saving: Supabase, or the browser when not configured
js/app.js                pages: start, colour setup, ledger
supabase-setup.sql       database tables, security rules and photo storage
tools/build_factions.py  rebuilds js/data/factions.js from BSData
```

## Hosting

Upload the whole folder to any static host (GitHub Pages, Netlify, Cloudflare Pages, your own server). There is no build step.

Without Supabase details the app saves to the visitor's browser, which is fine for trying it out.

## Supabase setup

1. Create a project at supabase.com.
2. SQL Editor → New query → paste `supabase-setup.sql` → Run.
3. Project Settings → API: copy the Project URL and the anon public key into `js/config.js`.
4. Authentication → URL Configuration: set Site URL to your hosted address.
5. Optional: Authentication → Providers → Email → turn off "Confirm email" if you want accounts to work without a confirmation email.

Each account sees only its own ledgers. To let anyone with a link view ledgers read-only, remove the dashes in front of the two "public read" lines in the SQL file and run it again.

## Updating unit data

Unit names, battlefield roles and weapon names come from the community BattleScribe data repository for 11th edition, [BSData/wh40k-11e](https://github.com/BSData/wh40k-11e). To refresh after a new codex or balance update:

```
git clone --depth 1 https://github.com/BSData/wh40k-11e bsdata
python3 tools/build_factions.py bsdata
```

That rewrites `js/data/factions.js`. Units marked Legends or Crucible in the data are listed separately under "Legends and other".

Warhammer 40,000 and all faction names are trademarks of Games Workshop. This is an unofficial fan tool. The emblem shapes are simple generic shapes, not official chapter or faction icons.
